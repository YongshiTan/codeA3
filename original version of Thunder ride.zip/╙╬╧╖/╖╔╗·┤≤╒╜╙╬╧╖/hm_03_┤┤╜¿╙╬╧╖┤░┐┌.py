import pygame

pygame.init()  # 调用pygame的初始化方法

# 创建游戏的窗口
screen = pygame.display.set_mode((480, 700))

while True:
    pass

pygame.quit()  # 调用pygame的退出方法
