import pygame
pygame.init()

# 编写游戏的代码
print("游戏的代码...")

pygame.quit()
