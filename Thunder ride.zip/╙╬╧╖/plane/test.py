l = [1,45,53]
x = [3,4]

print(l+x)